package pka.playkeyarena;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import javax.swing.table.DefaultTableModel;

    // user
    class User {
        private String username;
        private String password;

        public User(String username, String password) {
            this.username = username;
            this.password = password;
        }
       
        public String getUsername() {
            return username;
        }

        public String getPassword() {
            return password;
        }
    }

    // product o games title/price/image/details
    class Product {
        String name;
        double price;
        ImageIcon image;
        String details;

        public Product(String name, double price, ImageIcon image, String details) {
            this.name = name;
            this.price = price;
            this.image = image;
            this.details = details;
        }
    }

    // gawa transaction para sa receipts
    class Transaction {
        String userName;
        String productName;
        double productPrice;

        public Transaction(String userName, String productName, double productPrice) {
            this.userName = userName;
            this.productName = productName;
            this.productPrice = productPrice;
        }
    }

    // receipt then arraylist for productnames at total price
    class Receipt {
        private ArrayList<String> productNames;
        private double totalPrice;

        public Receipt(ArrayList<String> productNames, double totalPrice) {
            this.productNames = productNames;
            this.totalPrice = totalPrice;
        }

        public ArrayList<String> getProductNames() {
            return productNames;
        }

        public double getTotalPrice() {
            return totalPrice;
        }
    }
    
    // signup page
    class SignUp {
        private JTextField userTextField;
        private JPasswordField passField;
        private ArrayList<User> users;  // pag-aadd ng users as instance var

        public SignUp(JFrame parentFrame, ArrayList<User> users) {
            this.users = users;  // creating users list for multiple ppl
            JFrame signUpFrame = new JFrame("Sign Up");
            signUpFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            signUpFrame.setSize(300, 150);
            signUpFrame.setLayout(new GridLayout(3, 2));

            JLabel userLabel = new JLabel("New Username:");
            userTextField = new JTextField();

            JLabel passLabel = new JLabel("New Password:");
            passField = new JPasswordField();

            JButton signUpButton = new JButton("Sign Up");

            //adding signup frames
            signUpFrame.add(userLabel);
            signUpFrame.add(userTextField);
            signUpFrame.add(passLabel);
            signUpFrame.add(passField);
            signUpFrame.add(new JLabel()); // empty label for space
            signUpFrame.add(signUpButton);

            signUpFrame.setVisible(true);
            
            //signup button function
            signUpButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String newUsername = userTextField.getText();
                    char[] newPassword = passField.getPassword();

                    if (newUsername.length() > 0 && newPassword.length > 0) {
                        users.add(new User(newUsername, String.valueOf(newPassword)));
                        JOptionPane.showMessageDialog(signUpFrame, "Sign up successful! You can now log in.", "Success", JOptionPane.INFORMATION_MESSAGE);
                        signUpFrame.dispose();
                    } else {
                        JOptionPane.showMessageDialog(signUpFrame, "Please enter valid username and password.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            });
        }
    }

    public class PlayKeyArena {
        //ArrayList and LinkedList
        private static ArrayList<Product> products = new ArrayList<>();
        private static LinkedList<Transaction> transactions = new LinkedList<>();
        private static ArrayList<User> users = new ArrayList<>();

        // ito to make sure na initialize ang mga games only once
        static {
            initializeProducts();
        }
        
        public static void main(String[] args) {
    
            SwingUtilities.invokeLater(() -> {
                JFrame loginFrame = new JFrame("Login");
                loginFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                loginFrame.setSize(500, 400);
                loginFrame.setLayout(new GridLayout(3, 2));

                JLabel userLabel = new JLabel("Username:");
                JTextField userTextField = new JTextField();

                JLabel passLabel = new JLabel("Password:");
                JPasswordField passField = new JPasswordField();

                JButton loginButton = new JButton("Login");
                JButton signUpButton = new JButton("Sign Up");

                // login frames added
                loginFrame.add(userLabel);
                loginFrame.add(userTextField);
                loginFrame.add(new JLabel()); // empty label for space
                loginFrame.add(passLabel);
                loginFrame.add(passField);
                loginFrame.add(new JLabel()); // empty label for space
                loginFrame.add(signUpButton);


                loginButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        String username = userTextField.getText();
                        char[] password = passField.getPassword();

                        if (authenticateUser(username, password)) {
                            loginFrame.dispose();
                            openPlayKeyArena(username);
                        } else {
                            JOptionPane.showMessageDialog(loginFrame, "Invalid credentials. Please try again.", "Login Failed", JOptionPane.ERROR_MESSAGE);
                            passField.setText("");
                        }
                    }
                });

                signUpButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        new SignUp(loginFrame, users);
                    }
                });
                
                loginFrame.add(loginButton);

                loginFrame.setVisible(true);
            });
        }

        private static boolean authenticateUser(String username, char[] password) {
        for (User user : users) {
            if (user.getUsername().equals(username) && user.getPassword().equals(String.valueOf(password))) {
                return true; // authentication ng user successful
            }
        }
        return false; // authentication ng user failed
    }

        private static void showDetails(Product product) {
            JOptionPane.showMessageDialog(null, "Details for " + product.name + ":\n" + product.details, "Game Details", JOptionPane.INFORMATION_MESSAGE);
        }

        // ito ang main page after user signing up at login
        private static void openPlayKeyArena(String username) {
            JFrame frame = new JFrame("PlayKeyArena - Welcome, " + username);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(600, 400);

            JButton logoutButton = new JButton("Logout");
            JButton displayProductsButton = new JButton("Display Products");
            JButton purchaseProductButton = new JButton("Purchase Product");
            JButton displayTransactionsButton = new JButton("Display Transactions");

            JPanel productPanel = new JPanel();
            productPanel.setLayout(new GridLayout(0, 4));
            JScrollPane productScrollPane = new JScrollPane(productPanel);

            JPanel buttonPanel = new JPanel();
            buttonPanel.add(displayProductsButton);
            buttonPanel.add(purchaseProductButton);
            buttonPanel.add(displayTransactionsButton);
            buttonPanel.add(logoutButton);

            for (Product product : products) {
                // made image size the same
                ImageIcon resizedImage = resizeImageIcon(product.image, 100, 100);

                JLabel productLabel = new JLabel("<html><b>" + product.name + "</b><br>Price: $" + product.price + "</html>");
                productLabel.setIcon(resizedImage);

                JButton detailsButton = new JButton("Details");
                detailsButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        showDetails(product);
                    }
                });

                JPanel productPanelItem = new JPanel();
                productPanelItem.setLayout(new BorderLayout());
                productPanelItem.add(productLabel, BorderLayout.CENTER);
                productPanelItem.add(detailsButton, BorderLayout.SOUTH);

                productPanel.add(productPanelItem);
            }

            frame.getContentPane().setLayout(new BorderLayout());
            frame.getContentPane().add(buttonPanel, BorderLayout.NORTH);
            frame.getContentPane().add(productScrollPane, BorderLayout.CENTER);

            //display product button
            displayProductsButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    displayProducts(productPanel);
                }
            });
            
            //purchase product button 
            purchaseProductButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    purchaseProduct(frame, username);
                }
            });

            //transaction button
            displayTransactionsButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    displayTransactions(username);
                }
            });
            
            //logout button
            logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            
                int choice = JOptionPane.showConfirmDialog(frame, "Are you sure you want to logout?", "Logout", JOptionPane.YES_NO_OPTION);
                if (choice == JOptionPane.YES_OPTION) {
                    frame.dispose();
                    // ito po ay para irestart ang login process
                    main(null);
                }
            }
        });

        frame.setVisible(true);

        }
        private static void initializeProducts() {
            
            //C:/Users/Hi Hp/Documents/NetBeansProjects/PlayKeyArena/src/main/java/Images/bg1.jpg
            ImageIcon gameAImage = new ImageIcon("C:/Users/Hi Hp/Documents/NetBeansProjects/PlayKeyArena/src/main/java/Images/cs2.jpg");
            ImageIcon gameBImage = new ImageIcon("C:/Users/Hi Hp/Documents/NetBeansProjects/PlayKeyArena/src/main/java/Images/dota2.jfif");
            ImageIcon gameCImage = new ImageIcon("C:/Users/Hi Hp/Documents/NetBeansProjects/PlayKeyArena/src/main/java/Images/league.jfif");
            ImageIcon gameDImage = new ImageIcon("C:/Users/Hi Hp/Documents/NetBeansProjects/PlayKeyArena/src/main/java/Images/hogwarts.PNG");
            ImageIcon gameEImage = new ImageIcon("C:/Users/Hi Hp/Documents/NetBeansProjects/PlayKeyArena/src/main/java/Images/bg3.PNG");
            ImageIcon gameFImage = new ImageIcon("C:/Users/Hi Hp/Documents/NetBeansProjects/PlayKeyArena/src/main/java/Images/tek.PNG");
            ImageIcon gameGImage = new ImageIcon("C:/Users/Hi Hp/Documents/NetBeansProjects/PlayKeyArena/src/main/java/Images/dl.PNG");
            ImageIcon gameHImage = new ImageIcon("C:/Users/Hi Hp/Documents/NetBeansProjects/PlayKeyArena/src/main/java/Images/sf6.PNG");
            ImageIcon gameIImage = new ImageIcon("C:/Users/Hi Hp/Documents/NetBeansProjects/PlayKeyArena/src/main/java/Images/tok.PNG");
            ImageIcon gameJImage = new ImageIcon("C:/Users/Hi Hp/Documents/NetBeansProjects/PlayKeyArena/src/main/java/Images/swjs.PNG");
            
            for (Product product : products) {
            if (product.name.equalsIgnoreCase("Counter Strike 2")) {
                return; // iprevent po yung duplicating games every time naglog out and login   
            }
        }
            //adding games and image
            products.add(new Product("Counter Strike 2", 29.99, gameAImage, "Details about Counter Strike 2..."));
            products.add(new Product("Dota 2", 19.99, gameBImage, "Details about Dota 2..."));
            products.add(new Product("League of Legends", 39.99, gameCImage, "Details about League of Legends..."));
            products.add(new Product("Hogwarts Legacy", 49.99, gameDImage, "Details about Hogwarts Legacy..."));
            products.add(new Product("Battlegrounds 3", 59.99, gameEImage, "Details about Battlegrounds 3..."));
            products.add(new Product("Tekken 8", 29.99, gameFImage, "Details about Tekken 8..."));
            products.add(new Product("Dying Light", 29.99, gameGImage, "Details about Dying Light..."));
            products.add(new Product("Street Fighter 6", 29.99, gameHImage, "Details about Street Fighter 6..."));
            products.add(new Product("The Legend of Zelda: Tears of the Kingdom", 19.99, gameIImage, "Details about The Legend of Zelda: Tears of the Kingdom..."));
            products.add(new Product("Star Wars Jedi Survivor", 39.99, gameJImage, "Details about Star Wars Jedi Survivor..."));

            bubbleSort(products);
        }
        
        // bubblesort to sort the games alphabetically
        private static void bubbleSort(ArrayList<Product> productList) {
            int n = productList.size();
            for (int i = 0; i < n - 1; i++) {
                for (int j = 0; j < n - i - 1; j++) {
                    if (productList.get(j).name.compareTo(productList.get(j + 1).name) > 0) {
                        Collections.swap(productList, j, j + 1);
                    }
                }
            }
        }

        private static void displayProducts(JPanel productPanel) {
            productPanel.revalidate();
            productPanel.repaint();
        }

        private static ImageIcon resizeImageIcon(ImageIcon originalImage, int width, int height) {
            Image image = originalImage.getImage();
            Image newImage = image.getScaledInstance(width, height, Image.SCALE_SMOOTH);
            return new ImageIcon(newImage);
        }

        // users purchase product
        private static void purchaseProduct(JFrame parentFrame, String userName) {

            if (userName != null) {
                JPanel productPanel = (JPanel) ((JScrollPane) parentFrame.getContentPane().getComponent(1)).getViewport().getView();
                displayProducts(productPanel);

                String productName = JOptionPane.showInputDialog(parentFrame, "Enter the name of the product you want to purchase:");
                if (productName != null) {
                    double productPrice = getProductPrice(productName);

                    if (isProductValid(productName)) {
            transactions.add(new Transaction(userName, productName, productPrice));
            JOptionPane.showMessageDialog(parentFrame, "Purchase successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
            displayTransactions(userName); // pag-display ng transactions after purchase
        } else {
                        JOptionPane.showMessageDialog(parentFrame, "Invalid product. Please enter a valid product name.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        }

        //getting product price
        private static double getProductPrice(String productName) {
            for (Product product : products) {
                if (product.name.equalsIgnoreCase(productName)) {
                    return product.price;
                }
            }
            return 0.0;
        }

        private static Object[] getUserTransactionInfo(String userName) {
            //ArrayList
        ArrayList<String> userProductNames = new ArrayList<>();
        double userTotalPrice = 0.0;

        for (Transaction transaction : transactions) {
            if (transaction.userName.equalsIgnoreCase(userName)) {
                userProductNames.add(transaction.productName);
                userTotalPrice += transaction.productPrice;
            }
        }

        return new Object[]{userProductNames, userTotalPrice};
    }
        //transaction data/history
        private static Object[][] getUserTransactionsData(String userName) {
            Object[] userInfo = getUserTransactionInfo(userName);
            ArrayList<String> userProductNames = (ArrayList<String>) userInfo[0];

            Object[][] data = new Object[userProductNames.size()][2];

            for (int i = 0; i < userProductNames.size(); i++) {
                data[i][0] = userProductNames.get(i);

                // ito ay para sa pag-display ng product prices
                data[i][1] = getProductPrice(userProductNames.get(i));
            }

            return data;
        }

        // transactions display in table
        private static void displayTransactions(String userName) {
            String[] columnNames = {"Product Name", "Product Price"};
            Object[][] data = getUserTransactionsData(userName);

            double totalPrice = getUserTotalPrice(userName);
            Object[] totalRow = {"Total Price", totalPrice};

            DefaultTableModel model = new DefaultTableModel(data, columnNames);
            model.addRow(totalRow);

            JTable table = new JTable(model);  // table

            JScrollPane scrollPane = new JScrollPane(table);

            JOptionPane.showMessageDialog(null, scrollPane, "Transaction History and User Order Receipt", JOptionPane.INFORMATION_MESSAGE);
        }

        //getting user total price
        private static double getUserTotalPrice(String userName) {
            double userTotalPrice = 0.0;

            for (Transaction transaction : transactions) {
                if (transaction.userName.equalsIgnoreCase(userName)) {
                    userTotalPrice += transaction.productPrice;
                }
            }

            return userTotalPrice;
        }

        // for making sure na magkamatch ang product name sa tinype ng user
        private static boolean isProductValid(String productName) {
            for (Product product : products) {
                if (product.name.equalsIgnoreCase(productName)) {
                    return true;
                    }
                }
                return false;
            }


        }